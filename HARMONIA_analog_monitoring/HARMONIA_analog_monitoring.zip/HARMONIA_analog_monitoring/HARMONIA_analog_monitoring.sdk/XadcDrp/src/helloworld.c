/*
 * helloworld.c
 *
 *  Created on: 26.04.2015
 *      Author: JaksicS
 */


#include <stdio.h>
//#include "platform.h"

void print (char *str);

int main()
{

//init_platform();

	printf("Hello World\n\r");

	return 0;
}
